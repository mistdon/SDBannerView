//
//  ViewController.m
//  SHENDONGTEST
//
//  Created by shendong on 16/4/29.
//  Copyright © 2016年 com.sybercare.enterprise. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self makeListOfBubbles:5 color:6];
    
    NSArray *source = @[@12,@3,@23,@34,@35,@99,@98,@43];
    NSLog(@"source = %@",source);
    NSArray *result =  [self binarySort:source];
    
    NSLog(@"result = %@",result);
}

- (NSArray *)binarySort:(NSArray *)array {
    NSMutableArray *result = [array mutableCopy];
    for (NSInteger index = 0; index < result.count; index++) {
        NSInteger start, end, middle;
        start  = 0;
        end    = index - 1;
        middle = 0;
        NSInteger temp = [result[index] integerValue];
        while (start <= end) {
            middle = (start + end) / 2;
            if ([array[middle] integerValue] >  temp) {
                end = middle - 1;
            }else{
                start = middle + 1;
            }
        }
        for (NSInteger j = index - 1; j > end; j--) {
            NSLog(@"j = %ld,index = %ld, end = %ld",j, index, end);
            result[j+1] = result[j];
        }
        [result replaceObjectAtIndex:end+1 withObject:[NSNumber numberWithInteger:temp]];
    }

    return [result copy];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)makeListOfBubbles:(NSUInteger )ball color:(NSUInteger)color{
    NSLog(@"%s",__FUNCTION__);
    if ( ball > color) {
        NSLog(@"call");
        [NSException raise:@"Cannot " format:@"hh"];
        return;
    }
    
}
//int halfFuntion(int a[], int length, int number){
//    int start = 0; int end = length - 1; int index = 0;
//    while(start < end)  {
//        index = start + (end - start)/2;
//        if(a[index] == number){
//            return index;
//        } else if(a[index] < number){
//            start = index + 1;
//        } else{
//            end = index - 1;
//        }   }
//        return index;
//    }

@end
